//
//  ViewController.swift
//  Arithmetic
//
//  Created by Madugula,Abhiram on 2/14/19.
//  Copyright © 2019 Madugula,Abhiram. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var activityToMET:[String: Double] = ["Bicycling": 8.0,
    "Jumping rope": 12.3,
    "Running - slow": 9.8,
    "Running - fast": 23.0,
    "Tennis": 8.0,
    "Swimming": 5.8]

    @IBOutlet weak var ActivityTF: UITextField!
    @IBOutlet weak var WeightTF: UITextField!
    @IBOutlet weak var ExerciseTimeTF: UITextField!
    @IBOutlet weak var EnergyConsumedLBL: UILabel!
    @IBOutlet weak var TimeToLose1Pound: UILabel!
    
    @IBOutlet weak var ValidationLBL: UILabel!
    @IBAction func CalculateBTN(_ sender: Any) {
        
        if let during = ActivityTF.text, let weight = Double(WeightTF.text!), let time = Double(ExerciseTimeTF.text!){
        EnergyConsumedLBL.text = String(energyConsumed(during: during, weight: weight, time: time))
        TimeToLose1Pound.text = String(timeToLose1Pound(during: during, weight: weight))
        }
        else{
            ValidationLBL.text = "Please enter valid inputs"
        }
        
    }
    func energyConsumed(during: String,weight: Double,time: Double) -> Double{
        
        return activityToMET[during]! * 3.5 * weight * time / (200.0 * 2.2)
        
    }
    
    func timeToLose1Pound(during: String, weight: Double) -> Double{
        
        return 3500.0 / ((energyConsumed(during: during, weight: weight, time: Double(ExerciseTimeTF.text!)!)) / Double(ExerciseTimeTF.text!)!)
        
    }
    
    @IBAction func ClearBTN(_ sender: Any) {
        
        ActivityTF.text = " "
        WeightTF.text! = " "
        ExerciseTimeTF.text! = " "
        EnergyConsumedLBL.text = "0 cal"
        TimeToLose1Pound.text = "0 minutes"
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

